#!/bin/bash

# Variables
DATE=$(date -u -Is)
SLEEP=500
IFS=$'\n'
DIRECTORY=$(cd `dirname $0` && pwd)
cd ${DIRECTORY}
LOG="${DIRECTORY}/logs/monitor_voice_traffic.log"
SIPPENV="${DIRECTORY}/sippenviron"
COUNT=1
if [ -z $LOG ]; then
  touch $LOG
fi

while true; do
# Search for all active sipp pids
PID=($(pgrep sipp))

# source the environment file
. /home/interop/scripts/sippenviron

if [ $PID ]; then
  for i in ${PID[@]}; do
      IN=$(sudo find /home -name *${i}_.csv) # CSV File
      if [ -z $IN ];then break
      fi
      ERR_LOG=$(sudo find /home -name *${i}_errors.log) # ERROR LOGS
      ENV=$(echo $IN | sed -E 's/.*(Perf.*)\/.*/\1/g')
      IFS=";";read -a HDRS <<<`head -n 1 $IN`          # Add first line in CSV to HDRS Array
      IFS=";";read -a STATS <<<`tail -n 1 $IN`        # Add last line in CSV to STATS Array
      CURRENT=${STATS[13]} # 13 = CurrentCall from the CSV file
#      echo "${DATE} INFO: SIPP is running. PID ${PID[@]}" >> ${LOG}
#      echo " Current calls: $CURRENT" >> ${LOG}
      if [ $ERR_LOG ]; then
         STUCK=$(tail -c 250 $ERR_LOG | grep EPIPE)
      else
	 STUCK=""
      fi
      if [ $STUCK ]; then
		echo "${DATE} ERROR: SIPP is NOT responding - $COUNT - PID ${PID[@]}" >> ${LOG}
		echo "$STUCK"  >> ${LOG}
  		COUNT=$((COUNT+1))
      fi
     if [ $COUNT -gt 2 ]; then
             echo "${DATE} ERROR: SIPP is still NOT responding - $COUNT -Stopping PID ${PID[@]}" >> ${LOG}
             echo "${DATE} ERROR:  Executing 'kill -9 ${PID[@]}'" >> ${LOG}
             kill -9 ${PID[@]}
             echo "${DATE} ERROR: SIPp is GONE" >> ${LOG}
             COUNT=1
     fi
  done
  sleep $SLEEP
  DATE=$(date -u -Is)
else
  if [ $ERR_LOG ]; then
     FAILURE=$(tail -c 250 $ERR_LOG)
  fi

  echo "${DATE} WARNING: SIPP is NOT running" >> ${LOG}
  echo "   ERROR from SIPP: $FAILURE" >> ${LOG}
  echo "   cd $DIRECTORY"  >> ${LOG}
  echo "   CMD: $CMD"  >> ${LOG}
#  echo "   Should SIPp be running?: $ISRUN" >> ${LOG}
  echo "   Should SIPp be reboot?: $REBOOT" >> ${LOG}

  if [ $REBOOT = true ]; then
     	  echo "    ...yes it should be reboot" >> ${LOG}
     	  sed -i -E "s/(REBOOT\=).*/\1false/" ${SIPPENV}     	   
     	  sleep 30 
     	  /sbin/reboot
  else 
	  echo "    ...reboot completed and check traffic state" >> ${LOG}     	   	  
	  if [ $ISRUN = true ]; then
	  	  echo "   Should SIPp be running?: $ISRUN" >> ${LOG}
		  echo "    ...yes should be running" >> ${LOG}
	  	  cd $DIRECTORY
	  	  pwd >> ${LOG} 2>&1
		  #       $CMD >> ${LOG} 2>&1
	  	  ./voice-gen.sh --start $RATE >> ${LOG} 2>&1	
     	  fi	  	  

  fi
  sleep $SLEEP
  DATE=$(date -u -Is)
fi
done
exit 0

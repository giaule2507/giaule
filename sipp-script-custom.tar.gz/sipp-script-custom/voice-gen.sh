#! /bin/bash

#Text formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color
BELL='\007'
BELL='^G'

#Variables
DIRECTORY=$(cd `dirname $0` && pwd)
BSCRIPTNAME=$(basename $0)
SIPPENV=/home/interop/scripts/sippenviron
SCREEN_NAME=sipp-perf5-t5008
PARAMETER=`echo $2 | awk -F= '{print $1}'`
SCRIPT_VERSION="1.0"
SCRIPT_NAME=`basename "$0"`
SENTRY_FILE=($(pgrep sipp))
DATE=$(date -u -Is)
CP=8883
RAMPUPSCRIPT=/home/interop/scripts/rampSipp.sh
cd ${DIRECTORY}

PARAMS=(
	51.8.254.103:5060
        -inf 5000000.csv
        -t t1
        -p 5060
	-sf Azure_AM_DM_G711_SBC_in_queue.xml
        -cp ${CP}
        -r 10000
	-rp 3600000
        -l 1250
        -i 10.71.17.4
	-mi 10.71.17.4
	-d 325s
        -aa
        -trace_err
	-trace_screen
	-trace_stat
	-rtp_echo
        -max_reconnect 100000
        -reconnect_close false
	-max_recv_loops 100000
	-watchdog_minor_threshold 1500
	-oocsn ooc_default
	-skip_rlimit
	-deadcall_wait 2s
        -reconnect_sleep 300
)

function setcallrate {
        echo "Enter the maximum call rate for this SIPp instance"
        echo "The call rate format is number of calls in a 10 second period"
        echo "For example, enter 10 will set the call rate to 10 calls per 10 seconds,"
        echo "or 3600 BHCC"
        read -r -p "Call Rate: " SELECT
        callrate=$SELECT
        echo "Call rate set to $callrate"
        BHCC=$((($callrate*3600)/10))
        echo -e "${YELLOW}BHCC set to $BHCC${NC}"
}

helpFunction()
{
   echo ""
   echo "Usage: "

   echo '--start "Start voice traffic"'
   echo '--stop "Stop voice traffic"'
   echo '--status "Status Of voice traffic run"'
   echo '--pause "Pause voice traffic"'
   echo '--resume "Resume paused voice traffic"'

   echo '--version "Version information"'

   exit 1 # Exit script after printing help
}


start()
{
        printf "\n"
        echo -e "\e[1;33;40mSIPp startup script\e[0m"
        printf "\n"
        if [ "$SENTRY_FILE" ]; then
                echo -e "${YELLOW}Unable to start voice traffic, SIPp already running. PID $SENTRY_FILE ${NC}"
                printf "\n"
                exit -1
        fi

        if [ -z $PARAMETER ];then
        echo "Select the maximum call rate."
        select bhcc in "5K BHCC" "10K BHCC" "15K BHCC" "Other" "Exit"; do
                case $bhcc in
                        "5K BHCC" ) callrate=14; echo -e "${YELLOW}BHCC set to 5K${NC}"; break;;
                        "10K BHCC" ) callrate=27; echo -e "${YELLOW}BHCC set to 10K${NC}"; break;;
                        "15K BHCC" ) callrate=41; echo -e "${YELLOW}BHCC set to 15K${NC}"; break;;
                        "Other" ) setcallrate; break;;
                        "Exit"  ) exit;;
                esac
        done
        else
                callrate=${PARAMETER}
        fi
        echo "sudo sipp ${PARAMS[@]}"
        CMD="sudo sipp ${PARAMS[@]}"
	screen -dmS $SCREEN_NAME bash -c "$CMD"
        sleep 1
        screen -list
	CMD3="sed -n"
        PID=$(screen -list | grep ${SCREEN_NAME} | awk '{print $1}' | ${CMD3} "s/\(.*\)\.${SCREEN_NAME}/\1/p")

        if [[ -z $PID ]]; then
                echo "SIPp did not start correctly... Exiting"
                #               exit 1
		sed -i -E "s/(CMD\=).*/\1\"\.\/${BSCRIPTNAME} \-\-start ${callrate}\"/" ${SIPPENV}
                sed -i -E "s/(DIRECTORY\=).*/\1${DIRECTORY}/" ${SIPPENV}
                sed -i -E "s/(ISRUN\=).*/\1false/" ${SIPPENV}
		sed -i -E "s/(REBOOT\=).*/\1false/" ${SIPPENV}
                echo "cat ${SIPPENV}:"
                cat ${SIPPENV}
        else
                sed -i -E "s/(CMD\=).*/\1\"\.\/${BSCRIPTNAME} \-\-start ${callrate}\"/" ${SIPPENV}
		sed -i -E "s/(RATE\=).*/\1${callrate}/" ${SIPPENV}
                sed -i -E "s/(ISRUN\=).*/\1true/" ${SIPPENV}
		sed -i -E "s/(REBOOT\=).*/\1true/" ${SIPPENV}
                d=$'\03' # sed delimiter
                sed -i -E "s${d}(DIRECTORY\=).*${d}\1${DIRECTORY}${d}" ${SIPPENV}
                echo "SIPp started in separate screen shown above. Connect to screen $PID using the following command:"
                echo "screen -r $PID"
                echo ""
                sleep 1
                RAMP=$(pgrep ramp)
                if [ $RAMP ]; then
                        while [ $RAMP ]; do
				echo "Rampup sequence in progress. Stopping ..."
				sudo kill -9 $RAMP
				RAMP=$(pgrep ramp)
				sleep 1
 			done
                        echo "Rampup stopped."
	        fi
                sleep 1
                echo "Beginning the ramp up sequence in the background..."

                ###rampSipp.sh [Control Port] [sleep time] [max call rate]
#                $RAMPUPSCRIPT $CP 180 $callrate &
#                /home/locustuser/scripts/rampSipp.sh $CP 180 $callrate &
        fi
}

anywait(){

        while kill -0 "$PID" 2>&- ; do
            echo "Waiting for termination ..."
            sleep 3
        done
}

stop()
{
	sed -i -E "s/(ISRUN\=).*/\1false/" ${SIPPENV}
        if [ $SENTRY_FILE ]; then
                status
                echo "Stopping ..."
                sed -i -E "s/(ISRUN\=).*/\1false/" ${SIPPENV}
		sed -i -E "s/(REBOOT\=).*/\1false/" ${SIPPENV}
                RAMP=$(pgrep ramp)
                if [ $RAMP ]; then
                        while [ $RAMP ]; do
                                echo "Rampup sequence in progress. Stopping ..."
                                sudo kill -9 $RAMP
                                RAMP=$(pgrep ramp)
                                sleep 3
                        done
                        echo "Rampup stopped."
                fi

                echo "cset rate 0" >/dev/udp/127.0.0.1/$CP
                sleep 3
                echo "Stopping ..."
                while [ $CURRENT -gt 0 ] ; do
                  echo "Current calls: $CURRENT"
                  echo "Waiting for active calls to clear ..."
                  sleep 10
                  collect_stats
                done
                echo "q" >/dev/udp/127.0.0.1/$CP
                sleep 3
                SIPPID=($(pgrep sipp))
                if [ $SIPPID ]; then
                        echo "Unable to fully stop SIPp, check process manually by entering 'screen -x'"
                else
         	       echo "STOPPED"
                fi
        else
                echo "Unable to stop voice traffic, SIPp not running. PID $SENTRY_FILE"
                exit -1
        fi

        exit 0
}

pause()
{
        if [ $SENTRY_FILE ]; then
                status
                echo "Pausing ..."

                echo "p" >/dev/udp/127.0.0.1/$CP
                sleep 3
        else
               echo "Unable to pause voice traffic, SIPp not running. PID $SENTRY_FILE"
               exit -1

        fi
        exit 0
}


resume()
{
        if [ $SENTRY_FILE ]; then
                status
                echo "Resuming ..."
                echo "cset rate 3" >/dev/udp/127.0.0.1/$CP
                echo "p" >/dev/udp/127.0.0.1/$CP
		. $SIPPENV
                ###rampSipp.sh [Control Port] [sleep time] [max call rate]
                #/home/locustuser/scripts/rampSipp.sh $CP 180 27 &
                $RAMPUPSCRIPT $CP 180 $RATE &

                sleep 3
       else
               echo "Unable to resume voice traffic, SIPp not running. PID $SENTRY_FILE"
               exit -1

        fi
        exit 0
}
collect_stats()
{
        for i in ${SENTRY_FILE[@]}; do
              IN=$(sudo find /home -name *${i}_.csv) # CSV File
              if [ -z $IN ];then break
              fi
              ERR_LOG=$(sudo find /home -name *${i}_errors.log) # ERROR LOGS
              IFS=";";read -a HDRS <<<`head -n 1 $IN`          # Add first line in CSV to HDRS Array
              IFS=";";read -a STATS <<<`tail -n 1 $IN`        # Add last line in CSV to STATS Array
              CURRENT=${STATS[13]} # 13 = CurrentCall from the CSV file
              START=${STATS[0]} # 0 = StartTime from the CSV file
              ELAPSED=${STATS[4]} # 4 = ElapsedTime from the CSV file
        done
}
status()
{
        printf "\n"
        echo -e "\e[1;33;40mVoice Traffic status script\e[0m"
        printf "\n"
        if [ $SENTRY_FILE ]; then
        collect_stats
              echo -e "Status: ${GREEN}RUNNING${NC} - PID ${SENTRY_FILE[@]}"
              echo "Current calls: $CURRENT"
              echo "StartTime = $START"
              echo "ElapsedTime(C) = $ELAPSED"
              echo ""
        else
             echo -e "Status: ${RED}STOPPED${NC}"
             exit 0
        fi
}


version()
{
        echo "$BSCRIPTNAME $SCRIPT_VERSION"
#        $EXE_FILE --version

        exit 0
}

 case "$1" in
    --start)
      start
      ;;

    --stop)
      stop
      ;;

    --status)
      status
      ;;

    --pause)
      pause
      ;;

    --resume)
      resume
      ;;


    --version)
      version
      ;;
    *)
      helpFunction
      ;;
  esac


exit 0

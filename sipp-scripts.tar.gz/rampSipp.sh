#!/bin/bash

if [ $# -lt 3 ]; then
	echo "## rampSipp.sh [Control Port] [sleep time] [max call rate]"
	echo "## Example: rampSipp.sh 8884 300 27"
	exit 1
fi

CP=$1
snooze=$2
MAXRATE=$3

if [ $3 -lt 3 ]; then
	MAXRATE=3
fi

#INC=$(($MAXRATE/4))
RATE=3
INC=3
#Ramp up sequence
while (test "$RATE" -lt $MAXRATE) ; do
        echo "cset rate $RATE" >/dev/udp/127.0.0.1/$CP
        echo "Call Rate = $RATE"
        RATE=$((RATE+$INC))
        sleep $snooze
done
        echo "cset rate $MAXRATE" >/dev/udp/127.0.0.1/$CP
        echo "Max Call Rate = $MAXRATE"

exit 0
